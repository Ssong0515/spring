package bitc.fullstack405.securitytest.database.entity;

public enum Role {
    ROLE_ADMIN,
    ROLE_MEMBER
}
